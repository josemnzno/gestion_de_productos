package com.manzanoCorp.gestion_de_productos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionDeProductosApplicationTests {

	@Test
	void contextLoads() {
	}

}
